﻿
class App extends React.Component {
    render() {
        return (
            <div>
                <h1>Hello Sandip from App.jsx</h1>
               
            </div>
            );
    }

}
ReactDOM.render(<App />, document.getElementById("root"));

